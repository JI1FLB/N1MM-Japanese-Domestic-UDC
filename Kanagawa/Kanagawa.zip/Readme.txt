2018/06/02 9:21

神奈川コンテスト用UDCファイル、SECファイル

JI1FLB/田中　盛一

１．はじめに
２．目的
３．ファイル概要
kanagawa.udc	県内局用のUDCファイル
kanagawa.sec	県内局用のSECファイル
※上記2ファイルは、県外局としても利用可能。

kana-out.udc	県外局用のUDCファイル
kana-out.sec	県外局用のSECファイル

4.変更履歴
18/10/31 11:10:18
県外局用のUDC,SECファイルを廃止

