2018/06/09 16:53

山梨コンテスト用UDCファイル、SECファイル

JI1FLB/田中　盛一

１．はじめに

２．目的

３．ファイル概要
Yamanashi.udc		UDCファイル
Yamanakashi.sec		SECファイル


4.変更履歴
2018/06/09 16:57 ver1.1
Cabrilloファイル出力できるように変更


5．使い方
5.1　使い方　その１
コンテスト終了後に、N1MM Logger+でADIFファイルを出力する。
CTESTWINを起動し、ADIFファイルをインポートする。
CTESTWINでログ型式を整えて、ログを主催者に提出する。

5.2　使い方　その２
コンテスト終了後に、N1MM Logger+でCarbilloファイル出力する。
CTESWINを起動し、Carbilloファイルを読み込ませる。
CTESWINで、ログ形式を整えて、主催者にログを提出する。
